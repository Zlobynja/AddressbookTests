# csharp_training
repository for csharp learning
